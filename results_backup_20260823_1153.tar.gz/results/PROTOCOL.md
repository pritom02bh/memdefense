# Experimental Protocol

Recorded **before** the run at `2026-08-22T21:20:15+00:00`.

This file is written prior to execution so that the
configuration is a commitment rather than a reconstruction.
If any hash below differs from the hash recorded for another
set of cells, those cells are not directly comparable.

**Note:** Switched to gemini-3.1-flash-lite for cost; max_tokens=4000 in Mem0 extraction config after confirming Gemini 3.x reasoning tokens exhaust small budgets and return empty content.

## Run parameters

| parameter | value |
|---|---|
| group | `anchor_gemini` |
| backbone alias | `gemini-backbone` |
| turns ingested per conversation | 150 |
| question cap per cell | 75 |
| question selection | evidence-aligned (all evidence turns must survive truncation) |
| runs per cell | 1 |
| temperature | 0.0 (all roles) |
| adversarial scoring | deterministic abstention regex, no judge |

## Resolved models

Aliases are stable across the project; the models behind them
are not. This project has already lost two model strings
mid-flight (one deprecated `temperature`, one closed to new
users), so the concrete identifiers are recorded here.

| alias | resolves to |
|---|---|
| `answering` | `openai/gpt-4o-mini` |
| `claude-backbone` | `anthropic/claude-sonnet-4-5-20250929` |
| `embedding` | `openai/text-embedding-3-small` |
| `gemini-backbone` | `gemini/gemini-3.1-flash-lite` |
| `judge` | `openai/gpt-4o` |
| `judge-claude` | `anthropic/claude-haiku-4-5-20251001` |

## Price table in force

USD per million tokens. **Token counts are the durable
measurement**; dollar figures are a dated conversion and
should be reported as such. Costs can be recomputed exactly
from the raw token counts in `results/proxy/calls.jsonl`.

| model | input | output |
|---|---|---|
| `claude-haiku-4-5-20251001` | 1.0 | 5.0 |
| `claude-sonnet-4-5-20250929` | 3.0 | 15.0 |
| `gemini-3.1-flash-lite` | 0.25 | 1.5 |
| `gemini-3.6-flash` | 1.5 | 7.5 |
| `gpt-4o` | 2.5 | 10.0 |
| `gpt-4o-mini` | 0.15 | 0.6 |
| `text-embedding-3-small` | 0.02 | 0.0 |

## Dataset

- path: `data/locomo/locomo10.json`
- sha256 (first 16): `79fa87e90f040813`
- conversations used: as listed in `runner/cells.yaml`

## Code state

- git commit: `863e7eea02d6940e3e355167a9e90f810e1a0a55`
- branch: `main`

Behaviour-defining files (sha256, first 16):

| file | hash |
|---|---|
| `runner/run.py` | `2ad6d5c195479ad4` |
| `runner/cells.yaml` | `65d152dfd375fc4d` |
| `adapters/mem0_adapter.py` | `80cf8d822494a7bf` |
| `defenses/defenses.py` | `0183b2aca5bfefa9` |
| `defenses/base.py` | `8fd8a1f0a8b76556` |
| `core/judge.py` | `7a6a8fa6a1e0a672` |
| `core/evidence_filter.py` | `aca80cf59c13214e` |
| `core/dataset.py` | `511dbe11b3bbf3a2` |
| `prompts/judge.txt` | `4b4976ae9f461302` |
| `proxy/config.yaml` | `783a383b46b22845` |
| `proxy/logger.py` | `1b910f21ec1243bb` |

## Known limitations of this run

- **Single run per cell.** Variance reported across
  conversations only; model nondeterminism is not
  separated from between-conversation variance.
- **Truncation.** Conversations are cut to
  150 turns for cost. Questions are filtered to
  those answerable within that window, so absolute accuracy
  is not comparable to full-conversation LoCoMo results.
  Filtering changes question composition (multi-hop is
  disproportionately removed); report the retention table.
- **No attack.** This run measures benign-case cost only.
  No adversarial injection was performed, so no protection
  claim (ASR / dASR) can be made from these results.

